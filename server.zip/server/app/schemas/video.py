from pydantic import BaseModel
from typing import Optional

class VideoBase(BaseModel):
    title: str
    category: str
    youtube_id: str
    
class VideoCreate(VideoBase):
    pass
    
class VideoUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None
    youtube_id: Optional[str] = None
    
class Video(VideoBase):
    id: int
    
    class Config:
        form_attributes = True
        