from pydantic import BaseModel

class AdminBase(BaseModel):
    username: str
    
class AdminCreate(AdminBase):
    password: str
    
class Admin(AdminBase):
    id: int
    
    class Config:
        form_attributes = True