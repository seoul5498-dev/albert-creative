from pydantic import BaseModel
from typing import Optional

class ProjectBase(BaseModel):
    title: str
    type: str
    color: str
    
class ProjectCreate(ProjectBase):
    pass
    
class ProjectUpdate(BaseModel):
    title: Optional[str] = None
    type: Optional[str] = None
    color: Optional[str] = None
    
class Project(ProjectBase):
    id: int
    
    class Config:
        form_attributes = True