from pydantic import BaseModel
from typing import List, Optional

# Base Scheme with shared proprties
class ServiceBase(BaseModel):
    title: str
    icon: str
    color: str
    descrition: Optional[str] = None
    tags: List[str] = []
    
# schema for creating a service {Post Request}
class ServiceCreate(ServiceBase):
    pass
    
# schema for updating a service
class ServiceUpdate(BaseModel):
    title: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    
class Service(ServiceBase):
    id: int
    
    class Config:
        form_attributes = True