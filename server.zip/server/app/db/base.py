from app.db.base_class import Base

from app.models.service import Service
from app.models.video import Video
from app.models.project import Project
from app.models.admin import Admin