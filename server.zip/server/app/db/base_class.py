from sqlalchemy.orm import DeclarativeBase, declared_attr

class Base(DeclarativeBase):
    """
    Master Base class for SQLAlchemy 2.0 models.
    Inherits from DeclarativeBase (new standard), replacing the old @as_declarative.
    """
    
    # @declared_attr.directive fixes the Pyright/MyPy error.
    # It tells type checkers that this function returns a configuration string,
    # not a Mapped Column.
    @declared_attr.directive
    def __tablename__(cls) -> str:
        return cls.__name__.lower()