from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Albert Creative API"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = "qwertyuiop"
    SQLALCHEMY_DATABASE_URI: str = "sqlite:///./sql_app.db"
    
    class Config:
        case_sensitive = True
        
settings = Settings()